package com.app.pilotgearhub;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // declare variables
        Button loginButton = findViewById(R.id.btn_login);
        TextView signUpButton = findViewById(R.id.btn_signUp);
        TextView resetPassword = findViewById(R.id.btn_resetPass);

        // set on click listeners for each button
        loginButton.setOnClickListener(v -> login());
        signUpButton.setOnClickListener(v -> signUp());
        resetPassword.setOnClickListener(v -> resetPassword());

    }

    // declare methods for each function
    public void login() {
        startActivity(new Intent(this, Home.class));
        finish();
    }

    public void signUp() {
        startActivity(new Intent(this, SignUp.class));
        finish();
    }

    public void resetPassword() {
        startActivity(new Intent(this, ResetPass.class));
        finish();
    }

}