package com.app.pilotgearhub;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.viewpager2.widget.ViewPager2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

public class Home extends AppCompatActivity {

    private TabLayout tabLayout;
    private ViewPager viewPager2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        tabLayout = findViewById(R.id.tabLayout);
        viewPager2 = findViewById(R.id.viewPager2);

        tabLayout.setupWithViewPager(viewPager2);

        MyPagerAdapter viewPagerAdapter = new MyPagerAdapter(getSupportFragmentManager(), FragmentPagerAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        viewPagerAdapter.addFragment(new Fragment1(), "Electronics");
        viewPagerAdapter.addFragment(new Fragment2(), "Charts");
        viewPagerAdapter.addFragment(new Fragment3(), "Training and Sim");
        viewPager2.setAdapter(viewPagerAdapter);

        ImageButton showMenu = findViewById(R.id.showMenu);
        showMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMenu();
            }
        });
        ImageButton hideMenu = findViewById(R.id.hideMenu);
        hideMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hideMenu();
            }
        });

        Button profile = findViewById(R.id.profileBtn);
        profile.setOnClickListener(v -> openProfile());
        Button logout = findViewById(R.id.navbar_logout);
        logout.setOnClickListener(v -> logout());
    }
    public void showMenu() {
        NavigationView navbar = findViewById(R.id.navbar);
        navbar.setVisibility(View.VISIBLE);
    }
    public void hideMenu() {
        NavigationView navbar = findViewById(R.id.navbar);
        navbar.setVisibility(View.GONE);
    }
    public void openProfile() {
        startActivity(new Intent(this, Profile.class));
        finish();
    }
    public void logout(){
        startActivity(new Intent(this, MainActivity.class));
        Toast.makeText(this, "Logged out successfully!", Toast.LENGTH_SHORT).show();
        finish();
    }
}